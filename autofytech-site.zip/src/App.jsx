import { useState } from 'react'

const CALENDLY_LINK = '#'; // replace with your booking link if desired

export default function App() {
  const [open, setOpen] = useState(false)
  return (
    <div className="min-h-screen bg-[#0B1420] text-white">
      <div className="pointer-events-none fixed inset-0 -z-10">
        <div
          className="absolute inset-0 opacity-40"
          style={{
            background:
              'radial-gradient(1200px 600px at 80% -10%, rgba(37,198,202,0.35), rgba(11,20,32,0))',
          }}
        />
      </div>

      <header className="sticky top-0 z-20 backdrop-blur supports-[backdrop-filter]:bg-[#0B1420]/70">
        <nav className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
          <div className="flex items-center gap-3">
            <img
              src="/AutofyTech_Logo_HQ.jpg"
              alt="AutofyTech Logo"
              className="h-9 w-auto hidden sm:block"
              onError={(e) => {
                const el = e.currentTarget
                el.style.display = 'none'
                const svg = document.getElementById('logo-fallback')
                if (svg) svg.style.display = 'block'
              }}
            />
            <div id="logo-fallback" className="flex items-center gap-3" style={{ display: 'none' }}>
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none" className="text-[#25C6CA]">
                <path d="M4 17L11 4l3.5 6.2H9.5L7 17" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                <circle cx="7" cy="17" r="1.6" fill="currentColor" />
                <circle cx="9.5" cy="10.2" r="1.3" fill="currentColor" />
              </svg>
              <span className="text-xl font-semibold tracking-tight">AutofyTech</span>
            </div>
          </div>
          <div className="hidden items-center gap-8 md:flex">
            <a href="#solutions" className="text-sm opacity-80 hover:opacity-100">Solutions</a>
            <a href="#how" className="text-sm opacity-80 hover:opacity-100">How it works</a>
            <a href="#benefits" className="text-sm opacity-80 hover:opacity-100">Benefits</a>
            <a href="#faq" className="text-sm opacity-80 hover:opacity-100">FAQ</a>
          </div>
          <div className="flex items-center gap-3">
            <a href="tel:12044082309" className="hidden sm:block text-sm opacity-80 hover:opacity-100">(204) 408-2309</a>
            <button onClick={() => setOpen(true)} className="rounded-2xl bg-[#25C6CA] px-4 py-2 text-sm font-semibold text-[#0B1420] hover:brightness-110">Book a demo</button>
          </div>
        </nav>
      </header>

      <section className="mx-auto max-w-7xl px-6 pt-14 pb-16 md:pt-24">
        <div className="grid items-center gap-10 md:grid-cols-2">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-white/90">
              <span className="h-2 w-2 rounded-full bg-[#25C6CA]" /> 24/7 AI Receptionist for SMBs
            </div>
            <h1 className="mt-4 text-4xl font-semibold leading-tight md:text-5xl">Never miss a booking again.</h1>
            <p className="mt-4 max-w-xl text-white/80">
              AutofyTech answers calls, schedules appointments, and handles follow‑ups for small & midsize businesses. Purpose‑built for high‑volume phone workflows.
            </p>
            <div className="mt-6 flex flex-wrap items-center gap-3">
              <button onClick={() => setOpen(true)} className="rounded-2xl bg-[#25C6CA] px-5 py-3 font-semibold text-[#0B1420] hover:brightness-110">Book a demo</button>
              <a href="#solutions" className="rounded-2xl border border-white/10 px-5 py-3 font-semibold text-white/90 hover:bg-white/5">See solutions</a>
            </div>
            <div className="mt-6 text-sm text-white/60">
              Or email <a className="underline hover:text-white" href="mailto:Jonas@autofytek.com">Jonas@autofytek.com</a> • Call <a className="underline hover:text-white" href="tel:12044082309">(204) 408-2309</a>
            </div>
          </div>
          <div className="relative">
            <div className="rounded-3xl border border-white/10 bg-white/5 p-4 shadow-2xl">
              <div className="grid gap-3 sm:grid-cols-2">
                {[
                  { title: 'Live Call Answering', text: 'Greets callers, captures intent, routes or books.' },
                  { title: 'Smart Scheduling', text: 'Checks calendar, offers times, confirms instantly.' },
                  { title: 'Lead Qualification', text: 'Collects details, tags urgency, pushes to CRM.' },
                  { title: 'Follow‑ups & Reminders', text: 'SMS/email confirmations and reminders.' },
                ].map((f, i) => (
                  <div key={i} className="rounded-2xl border border-white/10 bg-[#0F1B29] p-4">
                    <h4 className="font-semibold text-white">{f.title}</h4>
                    <p className="mt-1 text-sm text-white/70">{f.text}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="solutions" className="mx-auto max-w-7xl px-6 py-16">
        <h2 className="text-3xl font-semibold">Solutions</h2>
        <p className="mt-2 max-w-2xl text-white/75">Designed for small to medium businesses with heavy call volume—think home services, clinics, salons, real estate, and service desks.</p>

        <div className="mt-8 grid gap-6 md:grid-cols-2">
          <Card title="AI Receptionist" bullets={[
            'Answers calls, web chat, and SMS',
            'Books & reschedules appointments',
            'Checks availability in Google/Outlook',
            'Logs to CRM (HubSpot, Pipedrive)',
            'Custom scripts & escalation rules',
          ]}
          cta="Book a demo" onCta={() => setOpen(true)} />

          <Card title="AI Automations" bullets={[
            'Intake forms → CRM + Slack',
            'After-hours call capture',
            'Missed-call SMS follow‑up',
            'Payment links & deposits',
            'Post‑visit review requests',
          ]}
          cta="See it in action" onCta={() => setOpen(true)} />
        </div>

        <div className="mt-10 rounded-3xl border border-white/10 bg-white/5 p-6">
          <p className="text-sm uppercase tracking-wider text-white/50">Integrates with</p>
          <div className="mt-3 flex flex-wrap items-center gap-4 text-white/80">
            {['Google Calendar','Outlook','Twilio','WhatsApp Business','Slack','Zapier','HubSpot','Stripe'].map((x)=> (
              <span key={x} className="rounded-full border border-white/10 bg-[#0F1B29] px-3 py-1 text-xs">{x}</span>
            ))}
          </div>
        </div>
      </section>

      <section id="how" className="mx-auto max-w-7xl px-6 py-16">
        <h2 className="text-3xl font-semibold">How it works</h2>
        <div className="mt-8 grid gap-6 md:grid-cols-4">
          {[
            { step: '01', title: 'Discovery', text: 'We map your call flows, booking rules, and integrations.' },
            { step: '02', title: 'Setup', text: 'Connect calendars/CRMs, craft scripts, define escalation paths.' },
            { step: '03', title: 'Go Live', text: 'Flip the switch for 24/7 coverage with analytics.' },
            { step: '04', title: 'Optimize', text: 'Iterate on prompts, improve conversion, expand automations.' },
          ].map((s) => (
            <div key={s.step} className="rounded-3xl border border-white/10 bg-white/5 p-6">
              <p className="text-sm text-white/50">{s.step}</p>
              <h4 className="mt-1 text-lg font-semibold">{s.title}</h4>
              <p className="mt-2 text-white/70">{s.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section id="benefits" className="mx-auto max-w-7xl px-6 py-16">
        <h2 className="text-3xl font-semibold">Why AutofyTech</h2>
        <div className="mt-8 grid gap-6 md:grid-cols-3">
          {[
            { title: 'Capture Every Lead', text: '0 missed calls. After‑hours and peak-time overflow handled automatically.' },
            { title: 'Frictionless Booking', text: 'Live availability checks and instant confirmations reduce no‑shows.' },
            { title: 'Lower Costs', text: 'Extend your team without hiring. Scale up for seasonality in minutes.' },
          ].map((b, i) => (
            <div key={i} className="rounded-3xl border border-white/10 bg-white/5 p-6">
              <h4 className="text-lg font-semibold">{b.title}</h4>
              <p className="mt-2 text-white/70">{b.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 pb-16">
        <div className="rounded-3xl border border-white/10 bg-[#0F1B29] p-6">
          <p className="text-sm uppercase tracking-wider text-white/50">Results</p>
          <div className="mt-3 grid gap-6 md:grid-cols-3">
            {[
              { kpi: '+35%', text: 'increase in booked appointments' },
              { kpi: '-80%', text: 'reduction in missed calls' },
              { kpi: '24/7', text: 'coverage with smart escalation' },
            ].map((r, i) => (
              <div key={i} className="rounded-2xl border border-white/10 bg-white/5 p-5 text-center">
                <div className="text-4xl font-bold text-[#25C6CA]">{r.kpi}</div>
                <div className="mt-1 text-white/70">{r.text}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="faq" className="mx-auto max-w-7xl px-6 pb-20">
        <h2 className="text-3xl font-semibold">FAQ</h2>
        <div className="mt-6 divide-y divide-white/10 rounded-2xl border border-white/10">
          {[
            { q: 'Can it handle complex booking rules?', a: 'Yes. We encode prep times, double bookings, provider constraints, deposit logic, and more.' },
            { q: 'Which CRMs do you support?', a: 'Most popular CRMs via native or Zapier integrations—HubSpot, Pipedrive, Salesforce (via Zapier), and others.' },
            { q: 'Do callers know it\'s AI?', a: 'You decide. We can present as a virtual assistant or transparently as AI, per your brand.' },
            { q: 'What about compliance?', a: 'We follow best practices for call recording/consent and secure data handling. Ask for our policy pack.' },
          ].map((item, i) => (
            <details key={i} className="group p-5">
              <summary className="cursor-pointer list-none text-lg font-medium marker:content-none">
                <span className="group-open:text-[#25C6CA]">{item.q}</span>
              </summary>
              <p className="mt-2 text-white/70">{item.a}</p>
            </details>
          ))}
        </div>
      </section>

      <footer className="border-t border-white/10 bg-[#0A131D]">
        <div className="mx-auto grid max-w-7xl gap-6 px-6 py-10 md:grid-cols-2">
          <div>
            <div className="flex items-center gap-3">
              <div className="h-8 w-8 rounded-xl bg-[#25C6CA]" />
              <div className="text-lg font-semibold">AutofyTech</div>
            </div>
            <p className="mt-3 max-w-md text-white/70">AI receptionist & business automations for high‑volume booking teams.</p>
          </div>
          <div className="md:justify-self-end">
            <p className="text-white/80">Contact</p>
            <p className="mt-1 text-white/70"><a className="underline hover:text-white" href="mailto:Jonas@autofytek.com">Jonas@autofytek.com</a></p>
            <p className="text-white/70"><a className="underline hover:text-white" href="tel:12044082309">(204) 408-2309</a></p>
            <div className="mt-4 flex gap-3">
              <button onClick={() => setOpen(true)} className="rounded-xl border border-white/10 bg-white/5 px-4 py-2 text-sm hover:bg-white/10">Book a demo</button>
              <a href="#solutions" className="rounded-xl border border-white/10 bg-white/5 px-4 py-2 text-sm hover:bg-white/10">Solutions</a>
            </div>
          </div>
        </div>
        <div className="border-t border-white/10 py-4 text-center text-xs text-white/50">© {new Date().getFullYear()} AutofyTech. All rights reserved.</div>
      </footer>

      {open && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/70 p-6" role="dialog" aria-modal>
          <div className="w-full max-w-lg rounded-3xl border border-white/10 bg-[#0F1B29] p-6 shadow-2xl">
            <div className="flex items-start justify-between">
              <h3 className="text-xl font-semibold">Book a demo</h3>
              <button onClick={() => setOpen(false)} className="rounded-full border border-white/10 px-3 py-1 text-sm text-white/70 hover:bg-white/5">Close</button>
            </div>
            <p className="mt-2 text-white/70">Tell us a bit about your business and we’ll set up a tailored walkthrough.</p>

            <form name="demo" method="POST" data-netlify="true" className="mt-4 grid gap-3">
              <input type="hidden" name="form-name" value="demo" />
              <label className="grid gap-1">
                <span className="text-sm text-white/80">Name</span>
                <input name="name" required className="rounded-xl border border-white/10 bg-[#0B1420] px-3 py-2 outline-none placeholder:text-white/40" placeholder="Jane Doe" />
              </label>
              <label className="grid gap-1">
                <span className="text-sm text-white/80">Company</span>
                <input name="company" className="rounded-xl border border-white/10 bg-[#0B1420] px-3 py-2 outline-none placeholder:text-white/40" placeholder="Acme Plumbing" />
              </label>
              <div className="grid gap-3 sm:grid-cols-2">
                <label className="grid gap-1">
                  <span className="text-sm text-white/80">Email</span>
                  <input type="email" name="email" required className="rounded-xl border border-white/10 bg-[#0B1420] px-3 py-2 outline-none placeholder:text-white/40" placeholder="you@company.com" />
                </label>
                <label className="grid gap-1">
                  <span className="text-sm text-white/80">Phone</span>
                  <input name="phone" className="rounded-xl border border-white/10 bg-[#0B1420] px-3 py-2 outline-none placeholder:text-white/40" placeholder="(555) 555-5555" />
                </label>
              </div>
              <label className="grid gap-1">
                <span className="text-sm text-white/80">What do you want to automate?</span>
                <textarea name="message" rows={4} className="rounded-xl border border-white/10 bg-[#0B1420] px-3 py-2 outline-none placeholder:text-white/40" placeholder="Booking overflow, after-hours calls, missed call SMS, CRM updates..." />
              </label>
              <div className="mt-2 flex items-center justify-between">
                <button type="submit" className="rounded-2xl bg-[#25C6CA] px-5 py-2 font-semibold text-[#0B1420] hover:brightness-110">Request demo</button>
                {CALENDLY_LINK !== '#' && (
                  <a href={CALENDLY_LINK} target="_blank" rel="noreferrer" className="text-sm text-white/70 underline hover:text-white">Or pick a time in Calendly</a>
                )}
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}

function Card({ title, bullets, cta, onCta }) {
  return (
    <div className="rounded-3xl border border-white/10 bg-white/5 p-6">
      <h3 className="text-xl font-semibold">{title}</h3>
      <ul className="mt-3 list-disc space-y-2 pl-5 text-white/75">
        {bullets.map((b, i) => (
          <li key={i}>{b}</li>
        ))}
      </ul>
      <button onClick={onCta} className="mt-5 rounded-xl border border-white/10 bg-[#0F1B29] px-4 py-2 text-sm hover:bg-white/10">{cta}</button>
    </div>
  )
}
